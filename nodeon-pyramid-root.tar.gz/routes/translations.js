const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

// GET /api/translations/:lang - Получение переводов по языку
router.get('/:lang', async (req, res) => {
  try {
    const { lang } = req.params;
    
    console.log(`🌐 Getting translations for language: ${lang}`);

    // Путь к файлу переводов
    const translationsPath = path.join(__dirname, '..', 'locales', `${lang}.json`);
    
    // Проверяем существование файла
    if (!fs.existsSync(translationsPath)) {
      console.log(`Translation file not found: ${translationsPath}`);
      return res.status(404).json({ error: 'Translation not found' });
    }

    // Читаем файл переводов
    const translations = JSON.parse(fs.readFileSync(translationsPath, 'utf8'));

    res.json({
      success: true,
      translations: translations
    });

  } catch (error) {
    console.error('Translations error:', error);
    res.status(500).json({ error: 'Failed to get translations' });
  }
});

module.exports = router;

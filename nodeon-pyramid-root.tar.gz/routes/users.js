const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// GET /api/users/find-by-id/:id - Поиск пользователя по внутреннему ID
router.get('/find-by-id/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    console.log(`👤 Finding user by ID: ${id}`);

    const { data: user, error } = await supabase
      .from('nodeon_users')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error('User fetch error:', error);
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        telegram_id: user.telegram_id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        balance_ndn: user.balance_ndn,
        is_pro: user.is_pro,
        referral_link: user.referral_link
      }
    });

  } catch (error) {
    console.error('Find user error:', error);
    res.status(500).json({ error: 'Failed to find user' });
  }
});

// POST /api/users/buy-pro - Покупка Pro статуса
router.post('/buy-pro', async (req, res) => {
  try {
    const { telegram_id } = req.body;
    
    console.log(`💎 Buying Pro status for user: ${telegram_id}`);

    if (!telegram_id) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing telegram_id' 
      });
    }

    const PRO_COST = 1000;

    // Получаем данные пользователя
    const { data: user, error: userError } = await supabase
      .from('nodeon_users')
      .select('*')
      .eq('telegram_id', telegram_id)
      .single();

    if (userError) {
      console.error('User fetch error:', userError);
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.is_pro) {
      return res.status(400).json({ 
        success: false, 
        error: 'User already has Pro status' 
      });
    }

    if (user.balance_ndn < PRO_COST) {
      return res.status(400).json({ 
        success: false, 
        error: 'Insufficient balance' 
      });
    }

    // Обновляем статус пользователя
    const newBalance = user.balance_ndn - PRO_COST;
    const referralLink = `https://t.me/pro_stars_bot?startapp=ref_${user.telegram_id}`;

    const { error: updateError } = await supabase
      .from('nodeon_users')
      .update({
        balance_ndn: newBalance,
        is_pro: true,
        referral_link: referralLink,
        updated_at: new Date().toISOString()
      })
      .eq('id', user.id);

    if (updateError) {
      console.error('Update error:', updateError);
      return res.status(500).json({ error: 'Failed to update user status' });
    }

    // Создаем транзакцию
    const { error: transactionError } = await supabase
      .from('nodeon_transactions')
      .insert({
        user_id: user.id,
        type: 'pro_purchase',
        amount_ndn: -PRO_COST,
        description: 'Pro status purchase',
        created_at: new Date().toISOString()
      });

    if (transactionError) {
      console.error('Transaction error:', transactionError);
    }

    res.json({
      success: true,
      message: 'Pro status purchased successfully',
      new_balance: newBalance,
      referral_link: referralLink
    });

  } catch (error) {
    console.error('Buy Pro error:', error);
    res.status(500).json({ error: 'Failed to buy Pro status' });
  }
});

module.exports = router;

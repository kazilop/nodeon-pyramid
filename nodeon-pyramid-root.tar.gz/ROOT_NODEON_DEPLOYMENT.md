# 🚀 NodeOn Pyramid - Развертывание в /root/nodeon

## 📋 Инструкции для папки /root/nodeon на Timeweb VPS

### 1. Подключение к серверу
```bash
ssh root@147.45.110.220
```

### 2. Создание папки и загрузка файлов
```bash
# Создаем папку для нашего приложения
mkdir -p /root/nodeon

# Загрузка архива (с локальной машины)
scp nodeon-pyramid-timeweb.tar.gz root@147.45.110.220:/root/

# Распаковка в нашу папку
cd /root/nodeon
tar -xzf /root/nodeon-pyramid-timeweb.tar.gz
```

### 3. Автоматическое развертывание
```bash
# Запуск автоматического скрипта
chmod +x timeweb-deploy.sh
./timeweb-deploy.sh
```

Скрипт автоматически:
- ✅ Создаст все необходимые папки в `/root/nodeon`
- ✅ Установит Node.js 18.x, PM2, Nginx, Certbot
- ✅ Настроит зависимости и конфигурации
- ✅ Запустит все сервисы
- ✅ Настроит firewall

### 4. Настройка переменных окружения
```bash
nano /root/nodeon/.env
```

Содержимое файла `.env`:
```env
NODE_ENV=production
PORT=3000

SUPABASE_URL=https://ahxwpzgltlzlvrtrbanm.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFoeHdwemdsdGx6bHZydHJiYW1tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk1MDMxNDksImV4cCI6MjA3NTA3OTE0OX0.h4sMVhVwvRUiHgbevDgv9W1G2S__uDWPUSCiXdrEy4E

TELEGRAM_BOT_TOKEN=7670372637:AAG7XWbNkhvNx_M4MI4118AYXvIsn3bRMDQ
TELEGRAM_BOT_USERNAME=pro_stars_bot

SECRET_KEY=your_secret_key_here
DEVELOPER_TELEGRAM_ID=207940967
```

### 5. Получение SSL сертификата
```bash
certbot --nginx -d sistemypro.ru -d www.sistemypro.ru
```

### 6. Финальный перезапуск
```bash
systemctl restart nginx
pm2 restart nodeon-pyramid
```

## 🎯 Результат

После развертывания ваше приложение будет доступно по адресу:
- **https://sistemypro.ru**
- **https://www.sistemypro.ru**

## 🔧 Управление

### Проверка статуса
```bash
# Статус приложения
pm2 status

# Статус Nginx
systemctl status nginx

# Проверка здоровья
curl http://localhost:3000/health
```

### Просмотр логов
```bash
# Логи приложения
pm2 logs nodeon-pyramid

# Логи Nginx
tail -f /var/log/nginx/error.log
```

### Обновление
```bash
cd /root/nodeon
./update.sh
```

## 📁 Итоговая структура

```
/root/nodeon/                     # Наше приложение
├── server.js                     # Express сервер (порт 3000)
├── public/index.html             # Фронтенд
├── routes/                       # API endpoints
├── .env                          # Переменные окружения
├── timeweb-deploy.sh            # Скрипт развертывания
└── logs/                         # Логи

/etc/nginx/sites-available/       # Конфигурации Nginx
└── nodeon                        # Наш сайт

/etc/nginx/sites-enabled/         # Активные сайты
└── nodeon -> ../sites-available/nodeon
```

## 🌐 Как работает

1. **Nginx** (порт 80/443) → обслуживает статические файлы из `/root/nodeon/public/`
2. **API запросы** (`/api/*`) → проксируются на Express сервер (порт 3000)
3. **Express сервер** → обрабатывает API и работает с Supabase
4. **PM2** → управляет процессом Express
5. **SSL** → обеспечивает HTTPS для Telegram Mini App

## ✅ Преимущества

- ✅ **Папка в /root** - удобное расположение
- ✅ **Автоматическое развертывание** - один скрипт для всего
- ✅ **Готово для Timeweb** - адаптировано для VPS
- ✅ **Несколько служб** - можно добавлять другие приложения
- ✅ **Простое управление** - PM2 + Nginx

## 🚨 Важные моменты

1. **Домен** должен быть настроен на IP `147.45.110.220`
2. **Порт 3000** должен быть свободен
3. **SSL сертификат** обязателен для Telegram Mini App
4. **Firewall** настроен для портов 22, 80, 443

## 🎉 Готово!

Ваше приложение NodeOn Pyramid будет работать в папке `/root/nodeon` на Timeweb VPS!

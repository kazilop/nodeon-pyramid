const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// GET /api/referrals/by-id/:id - Получение рефералов по внутреннему ID
router.get('/by-id/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    console.log(`👥 Getting referrals for user ID: ${id}`);

    // Получаем рефералов пользователя
    const { data: referrals, error } = await supabase
      .from('nodeon_users')
      .select('id, telegram_id, username, first_name, last_name, balance_ndn, is_pro, created_at')
      .eq('inviter_id', id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Referrals fetch error:', error);
      return res.status(500).json({ error: 'Failed to fetch referrals' });
    }

    // Получаем статистику рефералов
    const { data: stats, error: statsError } = await supabase
      .from('nodeon_referral_stats')
      .select('*')
      .eq('user_id', id);

    if (statsError) {
      console.error('Stats fetch error:', statsError);
    }

    res.json({
      success: true,
      referrals: referrals || [],
      stats: stats || []
    });

  } catch (error) {
    console.error('Get referrals error:', error);
    res.status(500).json({ error: 'Failed to get referrals' });
  }
});

module.exports = router;

const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const router = express.Router();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// GET /api/game/data/:telegram_id - Получение игровых данных
router.get('/data/:telegram_id', async (req, res) => {
  try {
    const { telegram_id } = req.params;
    
    console.log(`🎮 Getting game data for user: ${telegram_id}`);

    // Получаем данные пользователя
    const { data: user, error: userError } = await supabase
      .from('nodeon_users')
      .select('*')
      .eq('telegram_id', telegram_id)
      .single();

    if (userError) {
      console.error('User fetch error:', userError);
      return res.status(404).json({ error: 'User not found' });
    }

    // Получаем данные майнера
    const { data: minerData, error: minerError } = await supabase
      .from('nodeon_miner_data')
      .select('*')
      .eq('user_id', user.id)
      .single();

    const gameData = {
      level: 1,
      experience: 0,
      total_farms: minerData?.total_farms || 0,
      total_gas_earned: minerData?.gas || 0
    };

    res.json({
      success: true,
      game_data: gameData
    });

  } catch (error) {
    console.error('Game data error:', error);
    res.status(500).json({ error: 'Failed to get game data' });
  }
});

// GET /api/game/achievements - Получение достижений
router.get('/achievements', async (req, res) => {
  try {
    console.log('🏆 Getting achievements');

    const achievements = [
      {
        id: 'first_farm',
        name: 'First Farm',
        description: 'Buy your first farm',
        icon: '🏭',
        unlocked: false
      },
      {
        id: 'gas_collector',
        name: 'Gas Collector',
        description: 'Collect 1000 Gas',
        icon: '⛽',
        unlocked: false
      },
      {
        id: 'pro_status',
        name: 'Pro Player',
        description: 'Buy Pro status',
        icon: '💎',
        unlocked: false
      }
    ];

    res.json({
      success: true,
      achievements: achievements
    });

  } catch (error) {
    console.error('Achievements error:', error);
    res.status(500).json({ error: 'Failed to get achievements' });
  }
});

// POST /api/game/daily-reward - Получение ежедневной награды
router.post('/daily-reward', async (req, res) => {
  try {
    const { telegram_id } = req.body;
    
    console.log(`🎁 Claiming daily reward for user: ${telegram_id}`);

    if (!telegram_id) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing telegram_id' 
      });
    }

    // Получаем данные пользователя
    const { data: user, error: userError } = await supabase
      .from('nodeon_users')
      .select('*')
      .eq('telegram_id', telegram_id)
      .single();

    if (userError) {
      console.error('User fetch error:', userError);
      return res.status(404).json({ error: 'User not found' });
    }

    // Проверяем, получал ли пользователь награду сегодня
    const today = new Date().toISOString().split('T')[0];
    const { data: todayTransaction, error: transactionError } = await supabase
      .from('nodeon_transactions')
      .select('*')
      .eq('user_id', user.id)
      .eq('type', 'daily_reward')
      .gte('created_at', today)
      .single();

    if (todayTransaction) {
      return res.status(400).json({ 
        success: false, 
        error: 'Daily reward already claimed today' 
      });
    }

    // Выдаем награду (уменьшенную в 5 раз)
    const reward = 20; // Было 100, стало 20
    const newBalance = user.balance_ndn + reward;

    // Обновляем баланс
    const { error: updateError } = await supabase
      .from('nodeon_users')
      .update({ balance_ndn: newBalance })
      .eq('id', user.id);

    if (updateError) {
      console.error('Update error:', updateError);
      return res.status(500).json({ error: 'Failed to update balance' });
    }

    // Создаем транзакцию
    const { error: transactionCreateError } = await supabase
      .from('nodeon_transactions')
      .insert({
        user_id: user.id,
        type: 'daily_reward',
        amount_ndn: reward,
        description: 'Daily reward',
        created_at: new Date().toISOString()
      });

    if (transactionCreateError) {
      console.error('Transaction error:', transactionCreateError);
    }

    res.json({
      success: true,
      message: 'Daily reward claimed successfully',
      reward: reward,
      new_balance: newBalance
    });

  } catch (error) {
    console.error('Daily reward error:', error);
    res.status(500).json({ error: 'Failed to claim daily reward' });
  }
});

module.exports = router;
